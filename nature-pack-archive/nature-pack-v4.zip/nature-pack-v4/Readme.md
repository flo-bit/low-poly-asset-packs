# low poly nature pack

- 3 trees
- 3 dead trees
- 5 stones
- 3 pine trees
- 7 bushes
- 3 clouds
- 3 flowers
- 5 mushrooms
- 3 plants
- 3 palm trees
- 3 grass

glb, fbx, obj and blender files included.

made by flo-bit, find me here:

- [flo-bit.dev](https://flo-bit.dev)
- [itch.io](https://flo-bit.itch.io/)
- [twitter](https://x.com/flobit_dev)
- [github](https://github.com/flo-bit)

# changelog

- 0.1: initial release: pine trees, stones, common trees, dead trees (2024-10-06)
- 0.2: added more items: bushes, clouds, flowers, mushrooms, plants (2024-10-06)
- 0.3: adjust poly count of bigger models, added fbx, obj version, fix naming inconsistencies (2024-10-07)
- 0.4: added palm trees and grass (2024-10-09)

# license

cc0, do whatever you want with it, credits are appreciated though, also awesome if you write a comment if you're using it for a game :)