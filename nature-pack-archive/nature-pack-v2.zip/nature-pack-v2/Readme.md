# low poly nature pack

- 3 trees
- 3 dead trees
- 5 rocks
- 3 pine trees

GLB and blender files included.

Made by flo-bit, find me here:

- [flo-bit.dev](https://flo-bit.dev)
- [itch.io](https://flo-bit.itch.io/)
- [twitter](https://x.com/flobit_dev)
- [github](https://github.com/flo-bit)

# License

CC0, do whatever you want with it :)